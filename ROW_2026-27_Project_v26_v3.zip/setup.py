"""Rebuild the working directory from flat project files.

Project knowledge delivers every file to /mnt/project/ with no folders.
This puts them back into lib/ build/ data/ so the scripts can find
each other, then runs the checks.

    python3 /mnt/project/setup.py

Then work in /home/claude/row/.
"""
import os, shutil, subprocess, sys

SRC  = '/mnt/project'
WORK = '/home/claude/row'

LIB   = {'core.py', 'plan.py', 'turnaround.py', 'solve_lanes.py'}
BUILD = {'executive_summary.py', 'pool_grid.py', 'group_schedules.py',
         'schedules_by_coach.py', 'build_all.py'}
DATA  = {'CURRENT.json', 'pool_environment.json', 'capacity.json', 'group_names.json', 'fixed_lanes.json',
         'lane_overrides.json', 'pool_pins.json', 'tops_options.json',
         'lane_map.json', 'VERSION', 'row_logo.png', 'row_logo_b64.txt'}
ROOT  = {'check.py'}

for d in ('lib', 'build', 'data', 'output'):
    os.makedirs(os.path.join(WORK, d), exist_ok=True)

found, missing = [], []
for name, sub in [(n, 'lib') for n in LIB] + [(n, 'build') for n in BUILD] + \
                 [(n, 'data') for n in DATA] + [(n, '') for n in ROOT]:
    src = os.path.join(SRC, name)
    if os.path.exists(src):
        shutil.copy(src, os.path.join(WORK, sub, name))
        found.append(name)
    else:
        if name not in ('row_logo.png', 'lane_map.json'):
            missing.append(f'{sub}/{name}' if sub else name)

print(f'copied {len(found)} files into {WORK}')
if missing:
    print('MISSING from project knowledge:')
    for m in missing: print('   ', m)
    CRITICAL = ('core.py', 'plan.py', 'CURRENT.json', 'pool_environment.json',
                'check.py', 'VERSION')
    if any(m.endswith(CRITICAL) for m in missing):
        print('\nCannot continue without these. Add them and run setup again.')
        sys.exit(1)

if not os.path.exists(os.path.join(WORK, 'data', 'row_logo.png')) and \
   not os.path.exists(os.path.join(WORK, 'data', 'row_logo_b64.txt')):
    print('\nNo logo found. Documents will build without it.')

# lane_map.json is generated, so build it rather than complain
if not os.path.exists(os.path.join(WORK, 'data', 'lane_map.json')):
    print('data/lane_map.json not found, solving lanes...')
    r = subprocess.run([sys.executable, os.path.join(WORK, 'lib', 'solve_lanes.py')],
                       capture_output=True, text=True, cwd=WORK)
    print(r.stdout.strip() or r.stderr[-500:])
    if r.returncode:
        print('\nCould not solve lanes. Stopping.')
        sys.exit(1)
    print()

# a missing VERSION is easy to restore
vf = os.path.join(WORK, 'data', 'VERSION')
if not os.path.exists(vf):
    open(vf, 'w').write('v26\n')
    print('data/VERSION was missing, defaulted to v26. Check it is right.')

print()
r = subprocess.run([sys.executable, os.path.join(WORK, 'check.py')],
                   capture_output=True, text=True, cwd=WORK)
print(r.stdout or r.stderr[-800:])
