"""Load the plan and answer the questions every build script asks.

CURRENT.json is the single source of truth for the schedule.
Everything else in data/ describes how groups occupy the water.
"""
import json, os
from core import env, halves, need, SIZE, DAYS, D3, FA

D = os.path.join(os.path.dirname(__file__), '..', 'data')
def _load(n): return json.load(open(os.path.join(D, n)))

PLAN     = {k: [tuple(x) for x in v] for k, v in _load('CURRENT.json').items()}
FIXED    = _load('fixed_lanes.json')      # groups with a set lane count
OVERRIDE = {tuple(k.split('|')): v for k, v in _load('lane_overrides.json').items()}
CAPACITY = _load('capacity.json')         # maximum swimmers per group
NAMES    = {k: tuple(v) for k, v in _load('group_names.json').items()}
TOPS_OPT = _load('tops_options.json')     # which slots each TOPS option uses
LANEMAP  = {tuple(k.split('|')): v for k, v in _load('lane_map.json').items()}

# roster sizes used for the "in water" figures
SIZE['REC 14&U'] = 18; SIZE['REC 18&U'] = 20
SIZE['JD2'] = 18; SIZE['JD 4x'] = 18
SIZE['RD 18&U'] = 30; SIZE['RSA'] = 42
for g, c in CAPACITY.items():
    SIZE[g] = c

# maximum session length in hours
CAP = {'ND 18&U': 2.0, 'PD 18&U': 2.0, 'PD 14&U': 1.5, 'PD 12&U': 1.5,
       'RD 18&U': 2.0, 'RD 14&U': 1.5, 'RD 12&U': 1.5,
       'JD 4x': 1.5, 'JD2': 1.5, 'REC 14&U': 1.5, 'REC 18&U': 1.5, 'RSA': 3.0}
for t in TOPS_OPT: CAP[t] = 1.0

# swimmers per lane standard, by course
STD_SC = {'ND 18&U': 5, 'PD 18&U': 6, 'PD 14&U': 6, 'PD 12&U': 6, 'RD 18&U': 5,
          'RD 14&U': 6, 'RD 12&U': 6, 'JD 4x': 6, 'JD2': 6,
          'REC 14&U': 6, 'REC 18&U': 6}
STD_LC = {'ND 18&U': 8, 'PD 18&U': 9, 'PD 14&U': 9}
for t in TOPS_OPT: STD_SC[t] = 5


def lanes(g, d, r, f, crs=None):
    """How many lanes a group takes in a given session."""
    if g in FIXED: return FIXED[g]
    if crs is None: crs = env[f'{d}|{f}|{halves(r)[0]}']['crs']
    return OVERRIDE.get((g, d, r, f)) or (6 if g == 'RSA' else need(g, crs))


def hours(g):   return sum(len(halves(r)) * 0.5 for _, r, _ in PLAN[g])
def mornings(g): return sum(1 for d, r, _ in PLAN[g] if 'am' in r and d != 'Saturday')


def pool(g, d, r, f):
    """Which end of WLU a group is in, or the venue name."""
    if f != 'WLU': return FA[f]
    h = halves(r)[0]
    ls = [int(l) for (dd, ff, hh, l) in LANEMAP
          if (dd, ff, hh) == (d, f, h) and LANEMAP[(dd, ff, hh, l)] == g]
    if not ls: return 'WLU'
    return 'WLU deep end' if max(ls) <= 6 else 'WLU shallow end'


def name(g, with_age=True):
    n, age = NAMES.get(g, (g, ''))
    return f'{n}  \u2014  {age}' if (with_age and age) else n


def logo():
    """The ROW logo as an ImageReader, or None if it is not available.

    Prefers the PNG. Falls back to the base64 text copy, which is what
    survives project knowledge, since binaries do not.
    """
    import io, base64
    from reportlab.lib.utils import ImageReader
    png = os.path.join(D, 'row_logo.png')
    if os.path.exists(png):
        return ImageReader(png)
    txt = os.path.join(D, 'row_logo_b64.txt')
    if os.path.exists(txt):
        raw = base64.b64decode(''.join(open(txt).read().split()))
        return ImageReader(io.BytesIO(raw))
    return None


def order(x):
    """Sort a (group, day, time, facility) row into week order."""
    _, d, r, _ = x
    return (DAYS.index(d), 0 if 'am' in r else 1,
            int(r.split(':')[0]) % 12, int(r.split(':')[1][:2]))
