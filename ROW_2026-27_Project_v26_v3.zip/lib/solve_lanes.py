"""Assign every session to specific lanes.

Two rules govern the assignment:
  1. No group is split across the two WLU pools. Lanes 1-6 are the deep end,
     lanes 7-12 the shallow end. A group sits entirely in one or the other.
  2. PIN and FORCE record the placements that were chosen deliberately,
     so a rebuild does not quietly move a group to the other end.

Writes data/lane_map.json. Run this after any change to CURRENT.json.
"""
import json, os, sys
from collections import defaultdict
sys.setrecursionlimit(50000)
sys.path.insert(0, os.path.dirname(__file__))
from core import env, halves, need, SIZE, DAYS, D3, FA

D = os.path.join(os.path.dirname(__file__), '..', 'data')
def _load(n): return json.load(open(os.path.join(D, n)))

PLAN     = {k: [tuple(x) for x in v] for k, v in _load('CURRENT.json').items()}
FIXED    = _load('fixed_lanes.json')
OVERRIDE = {tuple(k.split('|')): v for k, v in _load('lane_overrides.json').items()}
PINS     = _load('pool_pins.json')

PIN   = {tuple(k.split('|')): v for k, v in PINS['pin'].items()}
FORCE = {tuple(k.split('|')): v for k, v in PINS['force'].items()}

def lanes(g, d, r, f, crs):
    if g in FIXED: return FIXED[g]
    return OVERRIDE.get((g, d, r, f)) or (6 if g == 'RSA' else need(g, crs))

def key(s):
    return (0 if 'am' in s else 1, int(s.split(':')[0]) % 12, int(s.split(':')[1][:2]))

SESS = defaultdict(list)
for g, ss in PLAN.items():
    for d, r, f in ss:
        hs = halves(r)
        SESS[(d, f)].append((g, r, hs, int(lanes(g, d, r, f, env[f'{d}|{f}|{hs[0]}']['crs']))))

def solve(d, f, ss, usepin=True):
    ss = sorted(ss, key=lambda s: (-(len(s[2]) * s[3]), key(s[2][0])))
    occ = {}
    def blocks(g, r, hs, n):
        if (g, d, r) in FORCE: return [FORCE[(g, d, r)]]
        cap = min(env[f'{d}|{f}|{h}']['lanes'] for h in hs)
        bases = [1, 7] if cap > 6 else [1]
        p = PIN.get((g, d)) if usepin else None
        if p == 'D': bases = [1]
        elif p == 'S' and cap > 6: bases = [7]
        out = [list(range(st, st + n)) for base in bases
               for st in range(base, base + 6 - n + 1) if st + n - 1 <= cap]
        if not out and n > 6 and n <= cap: out = [list(range(1, n + 1))]
        return out
    def rec(i):
        if i == len(ss): return True
        g, r, hs, n = ss[i]
        for blk in blocks(g, r, hs, n):
            if all((h, l) not in occ for h in hs for l in blk):
                for h in hs:
                    for l in blk: occ[(h, l)] = g
                if rec(i + 1): return True
                for h in hs:
                    for l in blk: del occ[(h, l)]
        return False
    return (occ, True) if rec(0) else (None, False)

MAP, relaxed, failed = {}, [], []
for (d, f), ss in SESS.items():
    occ, ok = solve(d, f, ss)
    if not ok:
        occ, ok = solve(d, f, ss, usepin=False)
        if ok: relaxed.append((d, f))
    if ok:
        for (h, l), g in occ.items(): MAP[(d, f, h, l)] = g
    else:
        failed.append((d, f))

print('failed days      :', failed or 'none')
print('pool preferences :', 'all honoured' if not relaxed else f'relaxed on {relaxed}')
json.dump({f'{k[0]}|{k[1]}|{k[2]}|{k[3]}': v for k, v in MAP.items()},
          open(os.path.join(D, 'lane_map.json'), 'w'))
print('wrote data/lane_map.json')
