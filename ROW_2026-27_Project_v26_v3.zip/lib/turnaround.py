"""Twelve hour turnaround check between an evening session and the next morning."""
from collections import defaultdict
from core import DAYS, D3, halves

def mins(t, ap=None):
    t=t.strip(); a='am' if 'am' in t else ('pm' if 'pm' in t else ap)
    t=t.replace('am','').replace('pm','').strip(); h,m=[int(x) for x in t.split(':')]
    if a=='pm' and h!=12: h+=12
    if a=='am' and h==12: h=0
    return h*60+m
def ends(r):
    a,b=[x.strip() for x in r.split('-')]
    return mins(b)
def starts(r):
    a,b=[x.strip() for x in r.split('-')]
    ap='am' if 'am' in a else ('pm' if 'pm' in a else ('am' if 'am' in b else 'pm'))
    return mins(a,ap)
def violations(P, gap=12*60):
    out=[]
    for g,ss in P.items():
        byday=defaultdict(list)
        for d,r,f in ss: byday[d].append((r,f))
        for i in range(len(DAYS)-1):
            d1,d2=DAYS[i],DAYS[i+1]
            pm=[r for r,f in byday.get(d1,[]) if 'pm' in r]
            am=[r for r,f in byday.get(d2,[]) if 'am' in r]
            if not pm or not am: continue
            e=max(ends(r) for r in pm); s=min(starts(r) for r in am)
            turn=(24*60-e)+s
            if turn<gap:
                out.append((g,D3[d1],max(pm,key=ends),D3[d2],min(am,key=starts),turn/60))
    return out
