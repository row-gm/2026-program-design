"""The water the club holds, and the helpers every script needs.

env is the pool contract: every half hour the club has booked, at every
venue, with how many lanes and whether the pool is short or long course.
It is loaded from data/pool_environment.json and is not derived from the
plan. That separation is the point. The rule "lanes fit the water we hold"
only means something if the two are recorded independently.

Defines: env, DAYS, D3, FA, SIZE, need(), halves().
"""
import json, math, os
from collections import defaultdict

_DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')

env = json.load(open(os.path.join(_DATA, 'pool_environment.json')))

DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
D3   = {'Monday': 'Mon', 'Tuesday': 'Tue', 'Wednesday': 'Wed',
        'Thursday': 'Thu', 'Friday': 'Fri', 'Saturday': 'Sat'}
FA   = {'WLU': 'WLU', 'Cameron Heights': 'CH', 'Rec Centre': 'RC'}

# Roster sizes. plan.py overwrites these with the published capacities;
# these are the fallback for anything not in capacity.json.
SIZE = {'ND 18&U': 12, 'PD 18&U': 15, 'PD 14&U': 18, 'PD 12&U': 18,
        'RD 18&U': 30, 'RD 14&U': 35, 'RD 12&U': 35,
        'JD 4x': 18, 'JD2': 18, 'RSA': 42}


def need(g, crs):
    """How many lanes a group needs at the per-lane standard for that course."""
    if g == 'RSA': return 6
    per = (8 if g.startswith('ND') else 9) if crs == 'LCM' else \
          (5 if g.startswith('ND') else 6)
    return math.ceil(SIZE[g] / per)


def halves(rng):
    """Split '4:30-6:00 pm' into the half hour slots it occupies."""
    a, b = [x.strip() for x in rng.split('-')]
    def ap(s, o):
        return 'am' if 'am' in s else ('pm' if 'pm' in s else
               ('am' if 'am' in o else 'pm'))
    def mins(t, p):
        t = t.replace('am', '').replace('pm', '').strip()
        h, m = [int(x) for x in t.split(':')]
        if p == 'pm' and h != 12: h += 12
        if p == 'am' and h == 12: h = 0
        return h * 60 + m
    s, e = mins(a, ap(a, b)), mins(b, ap(b, a))
    out, t = [], s
    while t < e:
        hh, mm = t // 60, t % 60
        h2, m2 = (t + 30) // 60, (t + 30) % 60
        out.append(f"{hh%12 or 12}:{mm:02d}-{h2%12 or 12}:{m2:02d} "
                   f"{'am' if hh < 12 else 'pm'}")
        t += 30
    return out
